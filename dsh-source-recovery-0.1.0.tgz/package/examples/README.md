# Three complete examples

All examples are local, offline and assume you own or are authorized to analyze
the target. Recovery commands require `--authorized`.

## 1. JavaScript source map → exact source (S0)

```powershell
# bundle.js ends with: //# sourceMappingURL=bundle.js.map
# bundle.js.map contains sources + sourcesContent
node bin/cli.js sourcemap --js .\bundle.js --out .\recovered --authorized --json
```

Expected:

```json
{ "ok": true, "level": "S0", "sources": 2, "recovered": 2, "outputDir": "...\\recovered" }
```

Result: `recovered/src/app.ts`, `recovered/src/util.ts`, plus
`sourcemap-manifest.json`. If the map has no `sourcesContent`, the level is
`S3` and only mappings/metadata are recovered.

## 2. Native binary → disassembly (S3, not source)

```powershell
gcc -O1 -o .\sample.exe .\sample.c
dsh-source-recovery .\sample.exe --output .\out --authorized --report .\report.md
```

Expected (minimal form):

```text
native/pe → level S3 (assembly-metadata)
output C:\...\out
disassembly recovered; native source is not recoverable locally (use REA/Ghidra for S2 pseudo-code)
report C:\...\report.md
```

Artifacts: `out/disassembly.txt`, `out/strings.txt`, `report.md`, `report.json`.
For pseudo-C (S2) install Ghidra or use the REA MCP (`mcp__rea__analyze_function`).

## 3. APK → Java source (S1)

```powershell
dsh-source-recovery .\authorized-app.apk --output .\apk-out --authorized --report .\apk-report.md
```

Expected:

```text
apk/apk → level S1 (near-source)
output C:\...\apk-out
jadx produced N Java/Kotlin files
```

Artifacts: `apk-out/jadx/sources/**/*.java`. If JADX is absent but apktool is
installed, the same command yields smali/resources (still S1). If neither is
installed, it reports S3 raw extraction and the gap — never a fake success.

> A synthetic APK with a real DEX compiled by Android `d8` is used in the test
> suite to verify this path end-to-end. Real-world obfuscated APKs may decompile
> partially; report the achieved level honestly.

## Check the environment first

```powershell
dsh-source-recovery doctor --json
dsh-source-recovery capabilities --json
```
