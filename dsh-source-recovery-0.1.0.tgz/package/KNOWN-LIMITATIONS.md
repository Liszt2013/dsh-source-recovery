# Known limitations`n`n> Revision note: the earlier 0.1.0 build registered its runtime skill without a `source` string, so DSH failed to load it with `loaded skill "..." source must be a string`. Fixed in this revision; the acceptance suite now loads the skill through DSH's own `SkillRegistry`.

1. **"Source" is often impossible.** Optimized native binaries, obfuscated
   managed code, stripped firmware and minified bundles without source maps do
   not contain original source. The plugin reports S1–S4 honestly.
2. **APK depth depends on JADX/apktool.** Locally JADX 1.5.6 and apktool are
   installed and tested via JAR/JADX. A real APK fixture was not executed in
   this workspace; the JAR path proves the JADX backend, the APK path uses the
   same handler but needs a locally authorized APK to verify end-to-end.
3. **.NET C# decompilation is unavailable locally** (`ilspycmd` absent); only
   managed metadata identification works. Use REA MCP managed tools.
4. **Native pseudo-code (S2) is unavailable locally** (no Ghidra/REA native in
   this plugin process); objdump gives S3 disassembly. Use REA/Ghidra for S2.
5. **Firmware extraction is unavailable locally** (no binwalk/unblob); only
   strings and magic identification are produced.
6. **No 7z/RAR/XZ/BZ2/ZIP64 extraction.** Detection only; documented gap.
7. **No dynamic analysis.** No execution, no sandbox detonation, no Frida, no
   network capture. Those require separate authorized tooling.
8. **No decryption of protected/encrypted archives or packed/obfuscated code.**
   No cracking, no bypass.
9. **No source-map-to-generated-code position resolver UI.** The plugin recovers
   `sourcesContent`; it does not rewrite mappings into an IDE-style view.
10. **APK resources are not fully decoded** without apktool's resource decoder;
    JADX runs with `--no-res` to keep the Java source path deterministic.
11. **REA MCP is not called by host code.** The plugin detects it; the model must
    invoke `mcp__rea__*` tools itself.
12. **Workbench is read-only** and shows no target paths or contents; operations
    go through tools/CLI.
13. **No browser visual regression** in this environment; the client graph and
    bundle are verified via acceptance, not screenshots.
14. **Only Windows was executed locally.** Linux/macOS behavior is expected but
    not executed in this run; APK/.NET/firmware backends vary by host.
15. **Package is `private`** and not published. Tarball is unsigned; verify its
    SHA-256 manually.
16. **Same-process plugin isolation is out of scope.** DSH approvals are not a
    sandbox for malicious plugins.
